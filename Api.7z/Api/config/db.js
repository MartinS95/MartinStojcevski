module.exports = {
  url: "mongodb://Stojcevski:mamataupi4ka@ds231658.mlab.com:31658/testingdb"
}
